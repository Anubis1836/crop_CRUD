import React, { Component } from 'react';


const Error = (props) =>{
    return(
        <div style={{color:'red'}}>
            Please add {props.name}
        </div>
    );
}
    


export default Error