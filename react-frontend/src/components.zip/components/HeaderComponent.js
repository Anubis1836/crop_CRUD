import React, { Component } from 'react'

class HeaderComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
                <header>
                    <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                    <div><a href="https://javaguides.net" className="navbar-brand">Farm Management System - KJSIEIT - SYIT - Sem 3 - Roll no - 45, 47, 52, 61       </a></div>
                    
                    </nav>

                     
                </header>
            </div>
        )
    }
}

export default HeaderComponent
